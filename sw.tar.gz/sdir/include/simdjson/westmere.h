#ifndef SIMDJSON_WESTMERE_H
#define SIMDJSON_WESTMERE_H

#include "simdjson/westmere/begin.h"
#include "simdjson/generic/amalgamated.h"
#include "simdjson/westmere/end.h"

#endif // SIMDJSON_WESTMERE_H